/**
 * @author Pablo Pavón Mariño, Technical University of Cartagena (Spain)
 * @version 0.1
 * 05/05/2013
 */
package com.jom;

/** 
 * 
 * @author Pablo Pavon Mariño
 * @see http://www.net2plan.com/jom
 */ 
public class JOMException extends RuntimeException
{
	public JOMException (String s) { super (s); }
}
